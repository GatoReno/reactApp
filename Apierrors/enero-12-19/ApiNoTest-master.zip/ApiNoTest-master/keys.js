module.exports = {
    db:{
        host: "localhost",
        user: "EdAdmin",//,
        password: "123456",//"123456", 
        port: 8889,//,8889
        database:  "UsersT",//"UsersT"
        socketPath: '/Applications/MAMP/tmp/mysql/mysql.sock'
    }
}